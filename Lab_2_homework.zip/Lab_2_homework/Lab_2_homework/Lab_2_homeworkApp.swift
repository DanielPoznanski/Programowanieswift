//
//  Lab_2_homeworkApp.swift
//  Lab_2_homework
//
//  Created by Przemyslaw Sipta on 22/03/2022.
//

import SwiftUI

@main
struct Lab_2_homeworkApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
