//
//  Lab3App.swift
//  Lab3
//
//  Created by Przemyslaw Sipta on 25/03/2022.
//

import SwiftUI

@main
struct Lab3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
